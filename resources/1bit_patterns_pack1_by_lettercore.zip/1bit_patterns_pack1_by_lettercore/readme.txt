100x2 seamless 1bit patterns (pack1)

- You can not use this in anything NFT-related.

- You cannot resell the pack and/or its parts (same applies for edits).

+ You can use this in your personal and commercial projects (as textures, brushes, etc…)

+ If you use this in a project consider mentioning the author.

For more information visit: https://lettercore.itch.io 

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

100x2 бесшовных однобитных текстур (комплект №1)

- Нельзя использовать в чём угодно, связанным с NFT.

- Нельзя перепродавать комплект полностью и/или частично (редактировать и перепродавать тоже нельзя).

+ Можно использовать в личных и коммерческих проектах (в качестве текстур, кистей, прочего…)

+ При использовании в проекте желательно упомянуть автора.

Больше информации на: https://lettercore.itch.io 